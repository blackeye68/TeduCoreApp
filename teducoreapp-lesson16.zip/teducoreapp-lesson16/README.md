# teducoreapp
Tedu Core App For Course TEDU-17
