﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeduCoreApp.Utilities.Constants
{
    public class CommonConstants
    {
        public const string DefaultFooterId = "DefaultFooterId";
    }
}
