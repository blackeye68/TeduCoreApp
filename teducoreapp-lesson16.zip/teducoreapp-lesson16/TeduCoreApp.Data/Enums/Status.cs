﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeduCoreApp.Data.Enums
{
    public enum Status
    {
        InActive,
        Active
    }
}
